package com.expensetracker.storage;

import com.expensetracker.model.Expense;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileStorage implements Storage {

    private static final String FILE_NAME = "expenses.txt";

    @Override
    public void save(List<Expense> expenses) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {

            for (Expense e : expenses) {
                writer.write(
                        e.getId() + "," +
                                e.getAmount() + "," +
                                e.getCategory() + "," +
                                e.getDescription() + "," +
                                e.getDate()
                );
                writer.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error saving expenses.");
        }
    }

    @Override
    public List<Expense> load() {
        List<Expense> expenses = new ArrayList<>();

        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return expenses;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                Expense expense = new Expense(
                        Integer.parseInt(data[0]),
                        Double.parseDouble(data[1]),
                        data[2],
                        data[3],
                        data[4]
                );

                expenses.add(expense);
            }

        } catch (IOException e) {
            System.out.println("Error loading expenses.");
        }

        return expenses;
    }
}
