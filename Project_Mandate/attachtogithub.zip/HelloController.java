package com.expensetracker.expensetrackerfx;

import com.expensetracker.model.Expense;
import com.expensetracker.service.ExpenseManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class HelloController {
    @FXML private TextField amountField;
    @FXML private TextField categoryField;
    @FXML private TextField descriptionField;
    @FXML private TextField dateField;
    @FXML private Label messageLabel;

    @FXML private TableView<Expense> expenseTable;
    @FXML private TableColumn<Expense, Integer> idColumn;
    @FXML private TableColumn<Expense, Double> amountColumn;
    @FXML private TableColumn<Expense, String> categoryColumn;
    @FXML private TableColumn<Expense, String> descriptionColumn;
    @FXML private TableColumn<Expense, String> dateColumn;

    private final ExpenseManager manager = new ExpenseManager();
    private final ObservableList<Expense> expenseList =
            FXCollections.observableArrayList();

    @FXML
    public void initialize() {

        idColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        amountColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("amount"));
        categoryColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("category"));
        descriptionColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("description"));
        dateColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("date"));
        // Load existing expenses from file
        expenseList.addAll(manager.getAllExpenses());

        expenseTable.setItems(expenseList);
        updateTotal();
    }
    @FXML
    private Label totalLabel;
    private void updateTotal() {
        double total = 0;
        for (Expense e : expenseList) {
            total += e.getAmount();
        }
        totalLabel.setText("Total Expense: ₹" + total);
    }

    @FXML
    private void handleDelete() {
        Expense selected = expenseTable.getSelectionModel().getSelectedItem();

        if (selected != null) {
            expenseList.remove(selected);
            manager.deleteExpense(selected); // we’ll add this next
            updateTotal();
            messageLabel.setText("Expense deleted.");
        } else {
            messageLabel.setText("No expense selected.");
        }
    }
    @FXML
    private void handleFilterCategory() {

        String category = categoryField.getText();

        if (category.isEmpty()) {
            messageLabel.setText("Enter category to filter.");
            return;
        }
        expenseList.setAll(manager.filterByCategory(category));
        updateTotal();
    }
    @FXML
    private void handleShowAll() {
        expenseList.setAll(manager.getAllExpenses());
        updateTotal();
    }


    @FXML
    private void handleFilterDate() {

        String date = dateField.getText();

        if (date.isEmpty()) {
            messageLabel.setText("Enter date to filter.");
            return;
        }

        expenseList.setAll(manager.filterByDate(date));
        updateTotal();
    }
    @FXML
    private void handleSortAmount() {
        expenseList.sort(java.util.Comparator.comparing(Expense::getAmount));
        updateTotal();
    }

    @FXML
    private void handleSortDate() {
        expenseList.sort(java.util.Comparator.comparing(Expense::getDate));
        updateTotal();
    }


    @FXML
    protected void handleAddExpense() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            String category = categoryField.getText();
            String description = descriptionField.getText();
            String date = dateField.getText();

            Expense expense = new Expense(
                    manager.getNextId(),
                    amount,
                    category,
                    description,
                    date
            );

            manager.addExpense(expense);
            expenseList.add(expense);
            updateTotal();
            messageLabel.setText("Expense added successfully!");

            amountField.clear();
            categoryField.clear();
            descriptionField.clear();
            dateField.clear();

        } catch (Exception e) {
            messageLabel.setText("Invalid input.");
        }
    }
}
