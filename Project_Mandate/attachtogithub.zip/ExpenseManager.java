package com.expensetracker.service;

import com.expensetracker.model.Expense;
import com.expensetracker.storage.FileStorage;
import com.expensetracker.storage.Storage;

import java.util.List;
import java.util.ArrayList;
public class ExpenseManager {

    private List<Expense> expenses;
    private Storage storage;

    public ExpenseManager() {
        storage = new FileStorage();
        expenses = storage.load();
    }

    public void addExpense(Expense expense) {
        expenses.add(expense);
        storage.save(expenses);
        System.out.println("Expense saved successfully!");
    }

    public void showAllExpenses() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses found.");
            return;
        }
        printHeader();
        for (Expense e : expenses) {
            printExpense(e);
        }
    }

    public List<Expense> filterByCategory(String category) {
        List<Expense> filtered = new ArrayList<>();

        for (Expense e : expenses) {
            if (e.getCategory().equalsIgnoreCase(category)) {
                filtered.add(e);
            }
        }

        return filtered;
    }


    public void deleteExpense(Expense expense) {
        expenses.remove(expense);
        storage.save(expenses);
    }

    public List<Expense> filterByDate(String date) {
        List<Expense> filtered = new ArrayList<>();

        for (Expense e : expenses) {
            if (e.getDate().equals(date)) {
                filtered.add(e);
            }
        }

        return filtered;
    }

    public List<Expense> getAllExpenses() {
        return expenses;
    }

    public double getTotalExpense() {
        double total = 0;
        for (Expense e : expenses) {
            total += e.getAmount();
        }
        return total;
    }


    public int getNextId() {
        return expenses.size() + 1;
    }

    private void printHeader() {
        System.out.println("ID | Amount | Category | Description | Date");
        System.out.println("---------------------------------------------");
    }

    private void printExpense(Expense e) {
        System.out.println(
                e.getId() + " | " +
                        e.getAmount() + " | " +
                        e.getCategory() + " | " +
                        e.getDescription() + " | " +
                        e.getDate()
        );
    }
}
