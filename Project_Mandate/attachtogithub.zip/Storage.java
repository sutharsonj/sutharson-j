package com.expensetracker.storage;

import com.expensetracker.model.Expense;

import java.util.List;

public interface Storage {
    void save(List<Expense> expenses);
    List<Expense> load();
}
